"use strict";
let nameWithWhitespace = "\t \n John Doe \t \n";
console.log("Name with whitespace:");
console.log(nameWithWhitespace);
let strippedName = nameWithWhitespace.trim();
console.log("\nName after stripping whitespace:");
console.log(strippedName);
