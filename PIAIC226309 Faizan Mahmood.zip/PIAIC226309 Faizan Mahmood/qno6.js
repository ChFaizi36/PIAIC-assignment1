"use strict";
// Addition
let additionResult = 25 + 63;
console.log("Addition Result:", additionResult);
// Subtraction
let subtractionResult = 10 - 7;
console.log("Subtraction Result:", subtractionResult);
// Multiplication
let multiplicationResult = 35 * 7;
console.log("Multiplication Result:", multiplicationResult);
// Division
let divisionResult = 40 / 8;
console.log("Division Result:", divisionResult);
