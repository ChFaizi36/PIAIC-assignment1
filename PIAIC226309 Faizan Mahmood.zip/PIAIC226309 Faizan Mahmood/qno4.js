"use strict";
let famous_person = "Allama Iqbal";
let quote = "Education is the most powerful weapon which you can use to change the world.";
let message = `${famous_person} once said, "${quote}"`;
console.log(message);
