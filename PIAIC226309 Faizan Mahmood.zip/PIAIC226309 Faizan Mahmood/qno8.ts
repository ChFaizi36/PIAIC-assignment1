
let favoriteNumber = 36;

let message = `My favorite number is ${favoriteNumber}.`;

console.log(message);
