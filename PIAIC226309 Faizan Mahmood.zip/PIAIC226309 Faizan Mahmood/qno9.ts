// Program to greet a person by name

let personName = "Eric";

// Create the message using the person's name
let message = `Hello ${personName}, would you like to learn some Python today?`;

// Print the message
console.log(message);
