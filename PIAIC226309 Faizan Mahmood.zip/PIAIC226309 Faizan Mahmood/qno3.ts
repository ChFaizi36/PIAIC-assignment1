let quote = "A person who never made a mistake never tried anything new.";
let author = "Albert Einstein";

console.log(`${author} once said, "${quote}"`);
