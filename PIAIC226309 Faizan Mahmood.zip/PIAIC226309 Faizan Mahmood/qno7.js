"use strict";
console.log(5 + 3);
console.log(10 - 2);
console.log(4 * 2);
console.log(32 / 4);
