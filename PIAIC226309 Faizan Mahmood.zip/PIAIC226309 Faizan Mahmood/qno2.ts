// Store the person's name in a variable
let personName = "John Doe";

// Convert the name to lowercase and print
let lowercaseName = personName.toLowerCase();
console.log("Lowercase: " + lowercaseName);

// Convert the name to uppercase and print
let uppercaseName = personName.toUpperCase();
console.log("Uppercase: " + uppercaseName);

// Convert the name to title case and print
let titlecaseName = personName.replace(/\b\w/g, firstLetter => firstLetter.toUpperCase());
console.log("Titlecase: " + titlecaseName);
